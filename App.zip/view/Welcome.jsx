import React   from 'react';




export default class Welcome extends React.Component {

	
	render() {

		return (
					<div>hi in welcome</div>
			);
	}


}